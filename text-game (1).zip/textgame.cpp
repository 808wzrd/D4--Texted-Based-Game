#include "libsqlite.hpp"                    // sqlite library
#include <iostream>
#include <string>
using namespace std;

/*class Menu
{
public:
    Menu(const string &name, const string &prompt, 
        const std::vector<std::pair<string, string> > &choices 
        = std::vector<std::pair<string, string> >{});
    virtual ~Menu();
    const string& getChoice() const;
    bool operator==(const string &name) const;
private:
    static const string menuend;
    string _name, _prompt;
    std::vector<std::pair<string, string> > _choices;
    
    
};*/
void Bedroom(string mystr)
{
    sqlite::sqlite db( "gamedb.sql" );    // open database
    cout << "Connected to database\n";
    auto cur = db.get_statement();            // create query
    cur->set_sql( "SELECT weapon FROM zone WHERE zone_id='Bedroom';" );
    cur->prepare();                            // run query

    while( cur->step() )                    // loop over results
        cout << cur->get_int(0) << " " << cur->get_text(1) << endl;
    
    cout<<"Chose Your weapon..Broom,Desk Lamp..That if you want to survive :)"<<".\n";
    cin>> mystr;
    if (mystr=="Broom"||"Desk Lamp")
    cout<<"Now use that "<<mystr<<" and kill those weakened zombies!!!"<<".\n";
};

void Entrance(string mystr)
{
    cout<<"Chose Your weapon..Flash light..That if you want to survive :)"<<".\n";
    cin>> mystr;
    if(mystr=="Flash light")
    cout<<"Now use that "<<mystr<<" and kill the Zombie General!!!"<<".\n";
    
};
void Hallway(string mystr)
{
    cout<<"Chose Your weapon..Fire Extinguisher,Picture Frame,Vase..That if you want to survive :)"<<".\n";
    cin>> mystr;
    if(mystr=="Fire Extinguisher"||"Picture Frame"||"Vase")
    cout<<"Now use that "<<mystr<<" and kill those Rats!!!"<<".\n";
};

void Kitchen(string mystr)
{
    cout<<"Chose Your weapon..Knife,Frying pan..That if you want to survive :)"<<".\n";
    cin>> mystr;
    if(mystr=="Knife"||"Frying pan")
    cout<<"Now use that "<<mystr<<" and kill that Zombie elite!!!"<<".\n";
};

void Study(string mystr)
{
    cout<<"Chose Your weapon..Sword,Hand gun..That if you want to survive :)"<<".\n";
    cin>> mystr;
    if(mystr=="Sword"||"Hand gun")
    cout<<"Now use that "<<mystr<<" and kill that Zombie General!!!"<<".\n";
};

int main ()
{
  string mystr;
  cout << "What's your name? "<<".\n";
  cin>> mystr;
  cout << "Hello Player " << mystr << ".\n";
  cout << "Where are you "<<mystr<<"?"<<".\n";
  cin>> mystr;
    if (mystr=="Bedroom")
    {
        Bedroom(mystr);
    }
    if (mystr=="Enterance")
    {
        Entrance(mystr);
    }
    if (mystr=="Hallway")
    {
        Hallway(mystr);
    }
    if(mystr=="Kitchen")
    {
        Kitchen(mystr);
    }
    if(mystr=="Study")
    {
        Study(mystr);
    }
    else
    {
        cout << "Error. Zone not available!";
    }
 
  return 0;
}