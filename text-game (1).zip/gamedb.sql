--
-- File generated with SQLiteStudio v3.1.0 on Wed Mar 8 11:57:20 2017
--
-- Text encoding used: System
--
PRAGMA foreign_keys = off;
BEGIN TRANSACTION;

-- Table: weapon
CREATE TABLE weapon (WEAPON_ID INT PRIMARY KEY, NAME TEXT, ZONE STRING, "ACTION" STRING, DURABILITY INT);
INSERT INTO weapon (WEAPON_ID, NAME, ZONE, "ACTION", DURABILITY) VALUES ('BB1', 'Broom', 'Bedroom', 'Swing', 2);
INSERT INTO weapon (WEAPON_ID, NAME, ZONE, "ACTION", DURABILITY) VALUES ('EF1', 'Flash Light', 'Entrance', 'Swing', 2);
INSERT INTO weapon (WEAPON_ID, NAME, ZONE, "ACTION", DURABILITY) VALUES ('BD1', 'Desk Lamp', 'Bedroom', 'Throw', 1);
INSERT INTO weapon (WEAPON_ID, NAME, ZONE, "ACTION", DURABILITY) VALUES ('HF1', 'Fire Extinguisher', 'Hallway', 'Swing', 5);
INSERT INTO weapon (WEAPON_ID, NAME, ZONE, "ACTION", DURABILITY) VALUES ('HP1', 'Picture Frame', 'Hallway', 'Throw', 4);
INSERT INTO weapon (WEAPON_ID, NAME, ZONE, "ACTION", DURABILITY) VALUES ('HV1', 'Vase', 'Hallway', 'Throw', 4);

-- Table: zone
CREATE TABLE zone (ZONE_ID STRING PRIMARY KEY, WEAPON REFERENCES weapon (WEAPON_ID), ENEMY);
INSERT INTO zone (ZONE_ID, WEAPON, ENEMY) VALUES ('Study', NULL, NULL);
INSERT INTO zone (ZONE_ID, WEAPON, ENEMY) VALUES ('Kitchen', NULL, NULL);
INSERT INTO zone (ZONE_ID, WEAPON, ENEMY) VALUES ('Maintenance Room', NULL, NULL);
INSERT INTO zone (ZONE_ID, WEAPON, ENEMY) VALUES ('Hallway', NULL, NULL);
INSERT INTO zone (ZONE_ID, WEAPON, ENEMY) VALUES ('Bedroom', NULL, NULL);
INSERT INTO zone (ZONE_ID, WEAPON, ENEMY) VALUES ('Enterance', NULL, NULL);

-- Table: user   
CREATE TABLE "user   " (user_id VARCHAR PRIMARY KEY, progress, curr_zone REFERENCES zone (ZONE_ID));

-- Table: action
CREATE TABLE "action" (ACTION_ID PRIMARY KEY, DAMAGE INT);

-- Table: enemy
CREATE TABLE enemy (ENEMY_ID PRIMARY KEY, ENEMY_HP, ZONE REFERENCES zone (ZONE_ID));

COMMIT TRANSACTION;
PRAGMA foreign_keys = on;
